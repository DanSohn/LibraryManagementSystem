package enums;

public enum ResourceStatus {
	
	AVAILABLE,
	UNAVAILABLE,
	REFERENCE;
	
}
