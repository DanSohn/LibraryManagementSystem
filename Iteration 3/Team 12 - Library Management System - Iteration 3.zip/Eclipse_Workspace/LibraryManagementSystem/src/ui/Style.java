package ui;

import java.awt.Color;

public class Style {
	static Color dBlue = new Color(3, 51, 89);
	static Color mBlue = new Color(15, 154, 187);
	static Color lBlue = new Color(230, 230, 240);
	static Color backBlue = new Color(122, 178, 201);
	static Color jBlue = new Color(210, 210, 210);
	
	public void run() {
		
	}
}