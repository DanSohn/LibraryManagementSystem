package consoleMenus;

public class Driver {
	
	public static void startLogin() {
		
		LoginMenu lm = new LoginMenu();
		lm.runMenu();
		
	}
	
}
