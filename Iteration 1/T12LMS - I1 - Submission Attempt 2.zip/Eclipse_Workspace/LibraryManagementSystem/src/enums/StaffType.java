package enums;

public enum StaffType {

	/*
	 * 
	 * ENUM TYPES
	 * 
	 */

	ADMIN, CLERK;

	/*
	 * 
	 * CONSTANTS & VARIABLES
	 * 
	 */

	/*
	 * 
	 * CONSTRUCTORS
	 * 
	 */

}
