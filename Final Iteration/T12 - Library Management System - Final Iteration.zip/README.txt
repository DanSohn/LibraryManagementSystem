T12LMS - I2

Team: 12
Project: Library Management System
Members:
	Matthew Allwright	- 30037812
	Karim Beyk			- 30027342
	Jacob Cuke			- 30030179
	Jacob Krmpotic
	Zander von Neudegg	- 30051361
	Daniel Sohn			- 30017825

Recommended for use on a 1080p monitor